#!c:/Dwimperl/Perl/bin/perl.exe
print "Content-type: text/html; charset=iso-8859-1\n\n";
use CGI;
use CGI::Carp qw(fatalsToBrowser);
$q=new CGI;
read(STDIN,$FormData,$ENV{'CONTENT-LENGTH'});


$num=$q->param("ch");


if($num==1) {
print "Details added\n";

open(DATA, ">>inner.txt");
$name=$q->param("name");
$email=$q->param("email");
$number=$q->param("number");
$password=$q->param("password");
$confirm=$q->param("confirm_password")
print DATA "$name-$email-$number-$password-$confirm_password\n";
close(DATA);
}





if($num==2) {
print "\nCustomer details edited.\n";
chomp($name=<>);



open(DATAC, "<viki.txt");
$count=0;
$i=0;
while(<DATAC>)
{
$count=$count+1;
}
close(DATAC);

$name=$q->param("name");


open(DATAWRITE, "<viki.txt");
@lines = <DATAWRITE>;
close(DATAWRITE);

open(DATAEDIT, ">viki.txt");

while($i<$count)
{
@array = split('-',$lines[$i]);
if($name eq $array[0])
{
$age=$q->param("age");
$city=$q->param("city");
$la=$q->param("amt");
print DATAEDIT "$name-$age-$city-$la\n";
}
else
{
print DATAEDIT "$array[0]-$array[1]-$array[2]-$array[3]";
}
$i=$i+1;
}
close(DATAEDIT);
}

if($num==3) {

open(DATAC, "<viki.txt");
$count=0;
$i=0;
while(<DATAC>)
{
$count=$count+1;
}
close(DATAC);

open(DATAR, "<viki.txt");
@lines = <DATAR>;
close(DATAR);

$i=0;
while($i<$count)
{
@array = split('-',$lines[$i]);
print "Name: $array[0]</br>";
print "Age: $array[1]</br>";
print "Loan Amount: $array[3]</br>";
print "City: $array[2]</br></br></br>";
$i=$i+1;
}
}



if($num==4) {
print "\nCustomer details deleted.\n";
chomp($name=<>);



open(DATAC, "<viki.txt");
$count=0;
$i=0;
while(<DATAC>)
{
$count=$count+1;
}
close(DATAC);

$name=$q->param("name");


open(DATAWRITE, "<viki.txt");
@lines = <DATAWRITE>;
close(DATAWRITE);

open(DATAEDIT, ">viki.txt");

while($i<$count)
{
@array = split('-',$lines[$i]);
if($name eq $array[0])
{

}
else
{
print DATAEDIT "$array[0]-$array[1]-$array[2]-$array[3]";
}
$i=$i+1;
}
close(DATAEDIT);
}
