<!DOCTYPE html>
<html>
<head>
	<style>
	    body{
	    	background-image: url(a.jpg);
	    	background-repeat: no-repeat;
	    	background-size: cover;
	    	background-image opacity:0.7 ;
	    }
		.Html_form{
			padding: 50px;

			
		}
		.Html_form form{
			margin: auto;
			padding: 50px;
			box-shadow: 1px 1px 16px black;
			width: 30%;
			text-align: center;
			background-color: white;
			border-radius: 10px;
		}
		.Html_form form h2{
			color: teal;
			font-family: verdana;
			font-size: 25px;
			padding: 10px;
		}
		.Html_form form input{
			width: 90%;
			margin: 10px;
			padding: 5px;
			border-radius: 5px;
			border: none;
			outline: none;
			border-left: 2px solid maroon;
			font-family: verdana;
		}
		.Html_form form input:focus{
			border-left: 2px solid blue;
			border-right: 2px solid blue ;
			box-shadow: 1px 1px 8px black;
		}
		.Html_form form select{
			width: 90%;
			margin: 10px;
			padding: 5px;
			border-radius: 5px;
			border: none;
			outline: none;
			border-left: 2px solid maroon;
			font-family: verdana;
		}
		.Html_form form select:focus{
			border-left: 2px solid blue;
			border-right: 2px solid blue ;
			box-shadow: 1px 1px 8px black;
		}
		.Html_form form button{
			padding: 10px;
			border: none;
			background-color: teal;
			color: white;
			font-weight: bold;
			font-family: verdana;
			font-size: 12px;
			border-radius: 5px;
			margin: 10px;
			box-shadow: 1px 1px 8px black;
		}

	</style>
	<meta charset="utf-8">
	<title>sign up|what to read next</title>
	
</head>
<body>
	<div class="Html_form">
		<form method="post" action="insert.php">
			<h2>REGISTER</h2>
			<input type="text" name="username" placeholder="username" required><br>
			<input type="password" name="password" placeholder="password" required><br>
			<input type="text" name="fullname" placeholder="full name" required><br>
			<input type="email" name="emailid" placeholder="email id" required><br>
			<input type="tel" name="contactnumber" placeholder="contact number" required><br>
			<select name="genre" required>
				<option>----genre(select one intial)----</option>
				<option>fantasy fiction</option>
				<option>romance</option>
				<option>mystery</option>
				<option>history</option>
				<option>horror</option>
				<option>fiction</option>
				<option>fey</option>
			</select><br>
			<input type="date" name="dateofbirth" placeholder="date of birth"><br>
			<button type="submit">Register</button>
			<button type="reset">refresh</button>
			
		</form>
	</div>

</body>
</html>